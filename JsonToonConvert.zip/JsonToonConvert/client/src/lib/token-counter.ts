export function countTokens(text: string): number {
  if (!text || text.trim().length === 0) {
    return 0;
  }
  
  let tokenCount = 0;
  let i = 0;
  
  while (i < text.length) {
    const char = text[i];
    
    if (/\s/.test(char)) {
      i++;
      continue;
    }
    
    if (/[a-zA-Z]/.test(char)) {
      let word = '';
      while (i < text.length && /[a-zA-Z0-9_]/.test(text[i])) {
        word += text[i];
        i++;
      }
      tokenCount += Math.max(1, Math.ceil(word.length / 4));
    }
    else if (/\d/.test(char)) {
      let num = '';
      while (i < text.length && /\d/.test(text[i])) {
        num += text[i];
        i++;
      }
      tokenCount += 1;
    }
    else {
      tokenCount += 1;
      i++;
    }
  }
  
  return tokenCount;
}
