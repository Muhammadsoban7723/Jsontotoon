export interface ToonOptions {
  delimiter?: ',' | '\t' | '|';
  indentSize?: number;
}

function needsQuotes(value: string, delimiter: string): boolean {
  const hasDelimiter = value.includes(delimiter);
  const hasColon = value.includes(':');
  const hasWhitespace = value.trim() !== value;
  const hasBrackets = value.includes('[') || value.includes(']');
  const hasSpecialChars = /["\n\r\t\\]/.test(value);
  const isReservedLiteral = value === 'true' || value === 'false' || value === 'null';
  
  return hasDelimiter || hasColon || hasWhitespace || hasBrackets || hasSpecialChars || isReservedLiteral;
}

function escapeString(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\t/g, '\\t');
}

function formatValue(value: any, delimiter: string): string {
  if (value === null) return 'null';
  if (typeof value === 'boolean') return String(value);
  if (typeof value === 'number') return String(value);
  if (typeof value === 'string') {
    if (needsQuotes(value, delimiter)) {
      return `"${escapeString(value)}"`;
    }
    return value;
  }
  return String(value);
}

function isUniformArray(arr: any[]): boolean {
  if (arr.length === 0) return false;
  if (!arr.every(item => typeof item === 'object' && item !== null && !Array.isArray(item))) {
    return false;
  }
  
  const firstKeys = Object.keys(arr[0]).sort();
  const isUniform = arr.every(item => {
    const keys = Object.keys(item).sort();
    return keys.length === firstKeys.length && 
           keys.every((key, i) => key === firstKeys[i]);
  });
  
  if (!isUniform) return false;
  
  const hasComplexValues = arr.some(item => 
    Object.values(item).some(val => 
      (typeof val === 'object' && val !== null) || Array.isArray(val)
    )
  );
  
  return !hasComplexValues;
}

function encodeToonValue(value: any, indent: string, options: ToonOptions): string {
  const { delimiter = ',', indentSize = 2 } = options;
  const nextIndent = indent + ' '.repeat(indentSize);
  
  if (value === null || typeof value === 'boolean' || typeof value === 'number') {
    return formatValue(value, delimiter);
  }
  
  if (typeof value === 'string') {
    return formatValue(value, delimiter);
  }
  
  if (Array.isArray(value)) {
    if (value.length === 0) {
      return `[0${delimiter}]:`;
    }
    
    if (value.every(item => typeof item !== 'object' || item === null)) {
      const items = value.map(v => formatValue(v, delimiter)).join(delimiter);
      return `[${value.length}${delimiter}]: ${items}`;
    }
    
    if (isUniformArray(value)) {
      const fields = Object.keys(value[0]);
      const fieldList = fields.join(delimiter);
      const rows = value.map(item => 
        fields.map(field => formatValue(item[field], delimiter)).join(delimiter)
      );
      return `[${value.length}${delimiter}]{${fieldList}}:\n${rows.map(row => nextIndent + row).join('\n')}`;
    }
    
    const items = value.map(item => {
      if (Array.isArray(item)) {
        const encoded = encodeToonValue(item, nextIndent + '  ', options);
        const lines = encoded.split('\n');
        if (lines.length === 1 && lines[0].startsWith('[')) {
          return `${nextIndent}- ${lines[0]}`;
        }
        return lines.map((line, idx) => idx === 0 ? `${nextIndent}- ${line.trim()}` : line).join('\n');
      }
      if (typeof item === 'object' && item !== null) {
        const encoded = encodeToonValue(item, nextIndent + '  ', options);
        const lines = encoded.split('\n');
        return lines.map((line, idx) => idx === 0 ? `${nextIndent}- ${line.trim()}` : line).join('\n');
      }
      return `${nextIndent}- ${formatValue(item, delimiter)}`;
    });
    return `[${value.length}${delimiter}]:\n${items.join('\n')}`;
  }
  
  if (typeof value === 'object' && value !== null) {
    const entries = Object.entries(value);
    if (entries.length === 0) {
      return '{}';
    }
    
    const lines = entries.map(([key, val]) => {
      if (val === null || typeof val === 'boolean' || typeof val === 'number' || typeof val === 'string') {
        return `${indent}${key}: ${formatValue(val, delimiter)}`;
      }
      
      if (Array.isArray(val)) {
        const arrayValue = encodeToonValue(val, nextIndent, options);
        if (arrayValue.startsWith('[') && arrayValue.includes(':\n')) {
          const parts = arrayValue.split(':\n');
          return `${indent}${key}: ${parts[0]}:\n${parts.slice(1).join(':\n')}`;
        }
        return `${indent}${key}: ${arrayValue}`;
      }
      
      if (typeof val === 'object') {
        const objValue = encodeToonValue(val, nextIndent, options);
        return `${indent}${key}:\n${objValue}`;
      }
      
      return `${indent}${key}: ${formatValue(val, delimiter)}`;
    });
    
    return lines.join('\n');
  }
  
  return formatValue(value, delimiter);
}

export function jsonToToon(jsonString: string, options: ToonOptions = {}): string {
  try {
    const data = JSON.parse(jsonString);
    const toon = encodeToonValue(data, '', options);
    return toon.trim();
  } catch (error) {
    throw new Error('Invalid JSON input');
  }
}

export function toonToJson(toonString: string): string {
  throw new Error('TOON to JSON conversion is not yet implemented');
}
