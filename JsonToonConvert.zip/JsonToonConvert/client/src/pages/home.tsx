import { useState } from "react";
import { Moon, Sun, ArrowRightLeft, Trash2, Copy, Download, Zap, Shield, Clock, ArrowRight, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useTheme } from "@/components/theme-provider";
import { jsonToToon } from "@/lib/toon-converter";
import { countTokens } from "@/lib/token-counter";
import { useToast } from "@/hooks/use-toast";

const SAMPLE_DATA = {
  "simple": {
    name: "Simple Object",
    json: JSON.stringify({ name: "Alice", age: 30, active: true }, null, 2)
  },
  "array": {
    name: "Array of Objects",
    json: JSON.stringify({
      users: [
        { id: 1, name: "Alice", email: "alice@example.com" },
        { id: 2, name: "Bob", email: "bob@example.com" },
        { id: 3, name: "Charlie", email: "charlie@example.com" }
      ]
    }, null, 2)
  },
  "nested": {
    name: "Nested Structure",
    json: JSON.stringify({
      user: {
        name: "Alice",
        contact: {
          email: "alice@example.com",
          phone: "555-1234"
        },
        tags: ["developer", "designer"]
      }
    }, null, 2)
  }
};

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const [jsonInput, setJsonInput] = useState("");
  const [toonOutput, setToonOutput] = useState("");
  const [error, setError] = useState("");
  const [selectedSample, setSelectedSample] = useState("");

  const handleConvert = () => {
    setError("");
    try {
      const toon = jsonToToon(jsonInput);
      setToonOutput(toon);
    } catch (err) {
      setError("Invalid JSON input. Please check your syntax and try again.");
      setToonOutput("");
    }
  };

  const handleSwap = () => {
    toast({
      title: "Coming Soon",
      description: "TOON to JSON conversion will be available in the next update.",
    });
  };

  const handleReset = () => {
    setJsonInput("");
    setToonOutput("");
    setError("");
    setSelectedSample("");
  };

  const handleCopy = async () => {
    if (!toonOutput) return;
    try {
      await navigator.clipboard.writeText(toonOutput);
      toast({
        title: "Copied!",
        description: "TOON output copied to clipboard.",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please try selecting and copying manually.",
        variant: "destructive"
      });
    }
  };

  const handleDownload = () => {
    if (!toonOutput) return;
    const blob = new Blob([toonOutput], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "output.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Downloaded!",
      description: "TOON output saved as output.txt",
    });
  };

  const handleSampleChange = (value: string) => {
    setSelectedSample(value);
    if (value && SAMPLE_DATA[value as keyof typeof SAMPLE_DATA]) {
      setJsonInput(SAMPLE_DATA[value as keyof typeof SAMPLE_DATA].json);
      setError("");
      setToonOutput("");
    }
  };

  const jsonTokens = countTokens(jsonInput);
  const toonTokens = countTokens(toonOutput);
  const savings = jsonTokens > 0 ? Math.round(((jsonTokens - toonTokens) / jsonTokens) * 100) : 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
              <Zap className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold">JSON to TOON Converter</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
          >
            {theme === "light" ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
          </Button>
        </div>
      </header>

      <main>
        <section className="container py-12 px-4 md:px-6 md:py-16">
          <div className="mx-auto max-w-7xl">
            <div className="mb-8 text-center">
              <h1 className="mb-3 text-3xl font-bold tracking-tight md:text-4xl">
                JSON to TOON Converter
              </h1>
              <p className="text-lg text-muted-foreground">
                Reduce LLM token usage by 30-60% with TOON format
              </p>
              <Badge variant="secondary" className="mt-3">
                100% Client-Side • Your data never leaves your device
              </Badge>
            </div>

            <div className="mb-6">
              <div className="flex items-center gap-3">
                <label htmlFor="sample-select" className="text-sm font-medium">
                  Try Sample:
                </label>
                <Select value={selectedSample} onValueChange={handleSampleChange}>
                  <SelectTrigger id="sample-select" className="w-[200px]" data-testid="select-sample">
                    <SelectValue placeholder="Select a sample..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="simple" data-testid="option-simple">Simple Object</SelectItem>
                    <SelectItem value="array" data-testid="option-array">Array of Objects</SelectItem>
                    <SelectItem value="nested" data-testid="option-nested">Nested Structure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="json-input" className="text-sm font-medium">
                    JSON Input
                  </label>
                  <Badge variant="outline" data-testid="badge-json-tokens">
                    {jsonTokens} tokens
                  </Badge>
                </div>
                <Textarea
                  id="json-input"
                  placeholder='{"name": "Alice", "age": 30}'
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  className="min-h-96 font-mono text-sm resize-none"
                  data-testid="textarea-json-input"
                />
                {error && (
                  <div className="flex items-center gap-2 text-sm text-destructive" data-testid="error-message">
                    <AlertCircle className="h-4 w-4" />
                    <span>{error}</span>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="toon-output" className="text-sm font-medium">
                    TOON Output
                  </label>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" data-testid="badge-toon-tokens">
                      {toonTokens} tokens
                    </Badge>
                    {savings > 0 && (
                      <Badge variant="default" data-testid="badge-savings">
                        {savings}% saved
                      </Badge>
                    )}
                  </div>
                </div>
                <Textarea
                  id="toon-output"
                  placeholder="TOON output will appear here..."
                  value={toonOutput}
                  readOnly
                  className="min-h-96 font-mono text-sm resize-none bg-muted/50"
                  data-testid="textarea-toon-output"
                />
              </div>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <Button
                size="lg"
                onClick={handleConvert}
                disabled={!jsonInput.trim()}
                data-testid="button-convert"
              >
                Convert to TOON
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleSwap}
                data-testid="button-swap"
              >
                <ArrowRightLeft className="h-4 w-4 mr-2" />
                Swap
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleReset}
                data-testid="button-reset"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Reset
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleCopy}
                disabled={!toonOutput}
                data-testid="button-copy"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleDownload}
                disabled={!toonOutput}
                data-testid="button-download"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </section>

        <section className="border-t bg-muted/30 py-16 px-4 md:px-6">
          <div className="container mx-auto max-w-6xl">
            <h2 className="mb-12 text-center text-3xl font-bold">
              Why Use JSON to TOON Converter?
            </h2>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <Zap className="h-10 w-10 text-primary mb-3" />
                  <CardTitle>Reduce Tokens by 30-60%</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    TOON format eliminates redundant JSON syntax like brackets, braces, and repeated keys — cutting token usage significantly.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Shield className="h-10 w-10 text-primary mb-3" />
                  <CardTitle>100% Private & Secure</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    All conversion happens locally in your browser. Zero data transmission, zero servers, zero tracking.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <Clock className="h-10 w-10 text-primary mb-3" />
                  <CardTitle>Instant Conversion</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Convert even large JSON files in milliseconds. Real-time processing with immediate results.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 md:px-6">
          <div className="container mx-auto max-w-4xl">
            <h2 className="mb-8 text-center text-3xl font-bold">
              Frequently Asked Questions
            </h2>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger data-testid="faq-what-is-toon">
                  What is TOON format?
                </AccordionTrigger>
                <AccordionContent>
                  TOON (Token-Oriented Object Notation) is a compact data format specifically designed for Large Language Models. It eliminates JSON's repetitive keys, excessive punctuation, and tokenization inefficiencies to reduce token usage by 30-60%.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger data-testid="faq-safe">
                  Is my data safe?
                </AccordionTrigger>
                <AccordionContent>
                  Absolutely! All conversion happens locally in your browser. Your JSON data never leaves your device, and we don't collect or store any information.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger data-testid="faq-llm">
                  Can LLMs like GPT-4 and Claude understand TOON format?
                </AccordionTrigger>
                <AccordionContent>
                  Yes! TOON is designed to be human-readable and LLM-friendly. Simply include TOON data in your prompts, and the models will understand it. You can even add instructions in your system prompt explaining the format.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger data-testid="faq-when">
                  When should I use TOON?
                </AccordionTrigger>
                <AccordionContent>
                  TOON works best with uniform arrays of objects (like user lists, product catalogs, or analytics data), large datasets, and scenarios where you need to maximize your LLM context window efficiency. For deeply nested or irregular structures, standard JSON might be more appropriate.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 px-4 md:px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
                  <Zap className="h-5 w-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-semibold">JSON to TOON Converter</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Free, secure, browser-based converter for reducing LLM token usage.
              </p>
              <p className="text-xs text-muted-foreground">
                © {new Date().getFullYear()} JSON to TOON Converter. All rights reserved.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">About TOON</h3>
              <p className="text-sm text-muted-foreground">
                TOON (Token-Oriented Object Notation) is an open format designed to optimize structured data for use with Large Language Models. Learn more about the specification on GitHub.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
